# Qayes Online Shop — Gallery Upload Update

This version adds image upload from a phone gallery in `/admin`.

1. Replace the GitHub repository's `app.py` with this file.
2. Keep your existing Render `ADMIN_KEY` environment variable.
3. Deploy the latest commit on Render.
4. Open `/admin`, enter the existing Admin Key, then choose a photo in the new file picker.

Image uploads are limited to 5 MB (JPG, JPEG, PNG, WEBP, GIF).

Important: Render free instance local storage can be temporary. Uploaded images and SQLite data may disappear after restarts/redeploys. For reliable production storage, use persistent object storage for images and PostgreSQL for data. This app does not process real card/bKash/Nagad payments.
